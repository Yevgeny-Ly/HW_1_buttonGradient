//
//  ViewController.swift
//  HW #1 buttonGradient
//
//  Created by Евгений Л on 01.07.2023.
//

import UIKit

final class ViewController: UIViewController {
    
    //MARK: - subView
    private var setupView: UIView   = {
       let views                    = UIView()
        views.layer.shadowColor     = UIColor.gray.cgColor
        views.layer.shadowOpacity   = 1.0
        views.layer.shadowRadius    = 5.0
        views.layer.shadowOffset    = .zero
        views.frame                 = .zero
        return views
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(setupView)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        setupView.frame = CGRect(x: 100, y: view.center.y-50, width: 100, height: 100)
        setupGradient()
    }
   
    //MARK: - Gradient setup
    private func setupGradient() {
        let gradient          = CAGradientLayer()
        gradient.frame        = setupView.bounds
        gradient.cornerRadius = 15.0
        gradient.colors       = [
            UIColor.systemBlue.cgColor,
            UIColor.systemMint.cgColor,
            UIColor.systemGreen.cgColor
        ]
        gradient.startPoint   = CGPoint(x: 0.0, y: 0.0)
        gradient.endPoint     = CGPoint(x: 1.0, y: 1.0)
        
        setupView.layer.insertSublayer(gradient, at: 0)
    }
}

